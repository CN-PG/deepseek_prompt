(function () {
  'use strict';

  const STORAGE_KEY = 'ds_prompt_helper_prompts';

  let allPrompts = [];

  // ============ 工具函数 ============
  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
  }

  function ensureIds(data) {
    let changed = false;
    data.forEach(cat => {
      if (!cat._id) { cat._id = uid(); changed = true; }
      cat.prompts.forEach(p => {
        if (!p.id) { p.id = uid(); changed = true; }
      });
    });
    return changed;
  }

  // ============ 加载默认数据 ============
  async function fetchDefaults() {
    const url = chrome.runtime.getURL('prompts.json');
    const res = await fetch(url);
    const data = await res.json();
    ensureIds(data);
    return data;
  }

  // ============ 存储读写 ============
  async function loadPrompts() {
    const result = await chrome.storage.local.get([STORAGE_KEY]);
    if (result[STORAGE_KEY] && result[STORAGE_KEY].length > 0) {
      allPrompts = result[STORAGE_KEY];
      const changed = ensureIds(allPrompts);
      if (changed) await chrome.storage.local.set({ [STORAGE_KEY]: allPrompts });
    } else {
      allPrompts = await fetchDefaults();
      await chrome.storage.local.set({ [STORAGE_KEY]: allPrompts });
    }
  }

  async function savePrompts() {
    await chrome.storage.local.set({ [STORAGE_KEY]: allPrompts });
  }

  function notifyContentScript() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && tabs[0].url && tabs[0].url.includes('chat.deepseek.com')) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'reloadPrompts' }).catch(() => {});
      }
    });
  }

  // ============ 插入到 DeepSeek ============
  function insertPrompt(text) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && tabs[0].url && tabs[0].url.includes('chat.deepseek.com')) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'insertPrompt', text }, () => {
          window.close();
        });
      } else {
        alert('请先在 DeepSeek 聊天页面打开此插件');
      }
    });
  }

  // ============ 渲染列表 ============
  function renderList(filter = '') {
    const container = document.getElementById('prompt-list-container');
    const keyword = filter.toLowerCase().trim();
    let html = '';

    allPrompts.forEach((cat, catIdx) => {
      const filtered = keyword
        ? cat.prompts.filter(p =>
            p.title.toLowerCase().includes(keyword) ||
            p.text.toLowerCase().includes(keyword) ||
            cat.category.toLowerCase().includes(keyword)
          )
        : cat.prompts;

      if (filtered.length === 0) return;

      const canUp = catIdx > 0;
      const canDown = catIdx < allPrompts.length - 1;
      html += `<div class="cat-group">
        <div class="cat-header">
          <span class="cat-header-text">${cat.icon || ''} ${cat.category}</span>
          <span class="cat-reorder">
            ${canUp ? '<button class="cat-move-up" data-cat="'+catIdx+'" title="上移">▲</button>' : '<span class="cat-move-spacer"></span>'}
            ${canDown ? '<button class="cat-move-down" data-cat="'+catIdx+'" title="下移">▼</button>' : '<span class="cat-move-spacer"></span>'}
          </span>
        </div>`;

      filtered.forEach(p => {
        html += `<div class="prompt-item" data-cat="${catIdx}" data-id="${p.id}">
          <span class="prompt-item-title">${p.title}</span>
          <button class="prompt-item-send" title="发送到 DeepSeek">▶</button>
          <button class="prompt-item-edit" title="修改">✏️</button>
          <button class="prompt-item-del" title="删除">×</button>
        </div>`;
      });

      html += '</div>';
    });

    container.innerHTML = html || '<p class="text-muted">暂无提示词</p>';
  }

  // ============ 事件委托 ============
  document.getElementById('prompt-list-container').addEventListener('click', (e) => {
    // 分类上移
    const moveUp = e.target.closest('.cat-move-up');
    if (moveUp) {
      const idx = parseInt(moveUp.dataset.cat);
      if (idx > 0) moveCategory(idx, idx - 1);
      return;
    }
    // 分类下移
    const moveDown = e.target.closest('.cat-move-down');
    if (moveDown) {
      const idx = parseInt(moveDown.dataset.cat);
      if (idx < allPrompts.length - 1) moveCategory(idx, idx + 1);
      return;
    }
    // 提示词操作
    const item = e.target.closest('.prompt-item');
    if (!item) return;

    const catIdx = parseInt(item.dataset.cat);
    const promptId = item.dataset.id;
    const pIdx = allPrompts[catIdx].prompts.findIndex(p => p.id === promptId);

    if (e.target.closest('.prompt-item-del')) {
      e.stopPropagation();
      deletePrompt(catIdx, pIdx);
    } else if (e.target.closest('.prompt-item-edit')) {
      e.stopPropagation();
      openEditModal(catIdx, pIdx);
    } else if (e.target.closest('.prompt-item-send')) {
      e.stopPropagation();
      insertPrompt(allPrompts[catIdx].prompts[pIdx].text);
    }
  });

  // ============ 分类排序 ============
  async function moveCategory(fromIdx, toIdx) {
    const item = allPrompts.splice(fromIdx, 1)[0];
    allPrompts.splice(toIdx, 0, item);
    await savePrompts();
    notifyContentScript();
    renderList(document.getElementById('search-prompts').value);
  }

  // ============ 删除提示词 ============
  async function deletePrompt(catIdx, pIdx) {
    const p = allPrompts[catIdx].prompts[pIdx];
    if (!confirm(`确定删除提示词「${p.title}」吗？`)) return;

    allPrompts[catIdx].prompts.splice(pIdx, 1);
    if (allPrompts[catIdx].prompts.length === 0) {
      allPrompts.splice(catIdx, 1);
    }
    await savePrompts();
    notifyContentScript();
    renderList(document.getElementById('search-prompts').value);
    loadCategorySelects();
  }

  // ============ 编辑弹窗 ============
  function openEditModal(catIdx, pIdx) {
    const p = allPrompts[catIdx].prompts[pIdx];
    document.getElementById('edit-cat-idx').value = catIdx;
    document.getElementById('edit-p-idx').value = pIdx;
    document.getElementById('edit-title').value = p.title;
    document.getElementById('edit-text').value = p.text;
    populateEditCategorySelect(allPrompts[catIdx].category);
    document.getElementById('edit-category-new').value = '';
    document.getElementById('edit-modal').style.display = 'flex';
  }

  function closeEditModal() {
    document.getElementById('edit-modal').style.display = 'none';
  }

  function populateEditCategorySelect(selectedCategory) {
    const select = document.getElementById('edit-category');
    select.innerHTML = '<option value="">选择分类...</option>';
    allPrompts.forEach(cat => {
      const opt = document.createElement('option');
      opt.value = cat.category;
      opt.textContent = `${cat.icon || ''} ${cat.category}`;
      if (cat.category === selectedCategory) opt.selected = true;
      select.appendChild(opt);
    });
  }

  document.getElementById('btn-edit-cancel').addEventListener('click', closeEditModal);
  document.getElementById('edit-modal').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeEditModal();
  });

  document.getElementById('btn-edit-save').addEventListener('click', async () => {
    const catIdx = parseInt(document.getElementById('edit-cat-idx').value);
    const pIdx = parseInt(document.getElementById('edit-p-idx').value);
    const title = document.getElementById('edit-title').value.trim();
    const text = document.getElementById('edit-text').value.trim();
    let category = document.getElementById('edit-category').value;
    const newCategory = document.getElementById('edit-category-new').value.trim();

    if (!title || !text) return alert('请填写标题和提示词内容');
    const finalCategory = newCategory || category;
    if (!finalCategory) return alert('请选择或输入一个分类');

    const prompt = allPrompts[catIdx].prompts[pIdx];

    // 检查重名（排除自身）
    const targetCat = allPrompts.find(c => c.category === finalCategory);
    if (targetCat) {
      const dup = targetCat.prompts.find(p => p.title === title && p.id !== prompt.id);
      if (dup) return alert('该分类下已存在同名提示词');
    }

    const oldCategory = allPrompts[catIdx].category;

    if (finalCategory === oldCategory) {
      prompt.title = title;
      prompt.text = text;
    } else {
      // 更换分类
      allPrompts[catIdx].prompts.splice(pIdx, 1);
      if (allPrompts[catIdx].prompts.length === 0) {
        allPrompts.splice(catIdx, 1);
      }
      if (!targetCat) {
        const iconMap = {
          '编程开发': '💻', '写作润色': '✍️', '学习辅助': '📚',
          '文档报告': '📝', '数据分析': '📊', '角色扮演': '🎭'
        };
        allPrompts.push({ _id: uid(), category: finalCategory, icon: iconMap[finalCategory] || '📌', prompts: [] });
      }
      const newCat = allPrompts.find(c => c.category === finalCategory);
      newCat.prompts.push({ id: prompt.id, title, text });
    }

    await savePrompts();
    notifyContentScript();
    renderList(document.getElementById('search-prompts').value);
    loadCategorySelects();
    closeEditModal();
  });

  // ============ 分类下拉框 ============
  function loadCategorySelects() {
    const select = document.getElementById('add-category');
    if (!select) return;
    select.innerHTML = '<option value="">选择分类...</option>';
    allPrompts.forEach(cat => {
      const opt = document.createElement('option');
      opt.value = cat.category;
      opt.textContent = `${cat.icon || ''} ${cat.category}`;
      select.appendChild(opt);
    });
  }

  // ============ 添加提示词 ============
  document.getElementById('add-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const msgEl = document.getElementById('add-msg');

    const title = document.getElementById('add-title').value.trim();
    const text = document.getElementById('add-text').value.trim();
    let category = document.getElementById('add-category').value;
    const newCategory = document.getElementById('add-category-new').value.trim();

    if (!title || !text) {
      msgEl.textContent = '请填写标题和提示词内容';
      msgEl.className = 'form-msg error';
      return;
    }

    const finalCategory = newCategory || category;
    if (!finalCategory) {
      msgEl.textContent = '请选择或输入一个分类';
      msgEl.className = 'form-msg error';
      return;
    }

    const iconMap = {
      '编程开发': '💻', '写作润色': '✍️', '学习辅助': '📚',
      '文档报告': '📝', '数据分析': '📊', '角色扮演': '🎭'
    };

    let catObj = allPrompts.find(c => c.category === finalCategory);
    if (!catObj) {
      catObj = { _id: uid(), category: finalCategory, icon: iconMap[finalCategory] || '📌', prompts: [] };
      allPrompts.push(catObj);
    }

    if (catObj.prompts.some(p => p.title === title)) {
      msgEl.textContent = '该分类下已存在同名提示词';
      msgEl.className = 'form-msg error';
      return;
    }

    catObj.prompts.push({ id: uid(), title, text });
    await savePrompts();
    notifyContentScript();

    msgEl.textContent = `已添加「${title}」到「${finalCategory}」分类`;
    msgEl.className = 'form-msg success';

    document.getElementById('add-form').reset();
    loadCategorySelects();
    renderList();
  });

  // ============ 恢复默认 ============
  document.getElementById('btn-reset').addEventListener('click', async () => {
    if (!confirm('确定恢复为默认提示词吗？这将覆盖所有自定义修改。')) return;
    allPrompts = await fetchDefaults();
    await savePrompts();
    notifyContentScript();
    renderList();
    loadCategorySelects();
  });

  // ============ 导出 ============
  document.getElementById('btn-export').addEventListener('click', () => {
    const exportData = allPrompts.map(({ _id, ...cat }) => ({
      ...cat,
      prompts: cat.prompts.map(({ id, ...p }) => p)
    }));
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'deepseek-prompts-backup.json';
    a.click();
    URL.revokeObjectURL(url);
  });

  // ============ 导入 ============
  document.getElementById('btn-import').addEventListener('click', () => {
    document.getElementById('import-file').click();
  });

  document.getElementById('import-file').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      if (!Array.isArray(data)) throw new Error('格式错误：需要 JSON 数组');

      const replace = confirm('点击"确定"替换全部提示词，点击"取消"则合并导入（跳过重名）');
      if (replace) {
        allPrompts = data;
      } else {
        for (const cat of data) {
          if (!cat.category || !Array.isArray(cat.prompts)) continue;
          let existing = allPrompts.find(c => c.category === cat.category);
          if (!existing) {
            existing = { _id: uid(), category: cat.category, icon: cat.icon || '📌', prompts: [] };
            allPrompts.push(existing);
          }
          for (const p of cat.prompts) {
            if (!existing.prompts.some(ep => ep.title === p.title)) {
              existing.prompts.push({ id: uid(), title: p.title, text: p.text });
            }
          }
        }
      }
      ensureIds(allPrompts);
      await savePrompts();
      notifyContentScript();
      renderList();
      loadCategorySelects();
      showToast('导入成功');
    } catch (err) {
      alert('导入失败：' + err.message);
    }
    e.target.value = '';
  });

  // ============ Toast ============
  function showToast(msg) {
    let toast = document.getElementById('ph-popup-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'ph-popup-toast';
      toast.className = 'popup-toast';
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toast._timeout);
    toast._timeout = setTimeout(() => toast.classList.remove('show'), 2000);
  }

  // ============ Tab 切换 ============
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById('tab-' + btn.dataset.tab).classList.add('active');

      if (btn.dataset.tab === 'list') {
        loadCategorySelects();
        renderList();
      }
    });
  });

  // ============ 搜索（防抖） ============
  let searchTimer;
  document.getElementById('search-prompts').addEventListener('input', (e) => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => renderList(e.target.value), 200);
  });

  // ============ 启动 ============
  async function init() {
    await loadPrompts();
    loadCategorySelects();
    renderList();
  }

  init();
})();
