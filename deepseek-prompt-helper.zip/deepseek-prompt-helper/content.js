(function () {
  'use strict';

  // ============ 配置 ============
  const PANEL_ID = 'ph-prompt-panel';
  const TRIGGER_ID = 'ph-trigger-btn';
  const TOAST_ID = 'ph-toast';
  const STORAGE_KEY = 'ds_prompt_helper_prompts';

  let allPrompts = [];
  let isPanelOpen = false;

  // ============ 工具函数 ============
  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
  }

  function ensureIds(data) {
    let changed = false;
    data.forEach(cat => {
      if (!cat._id) { cat._id = uid(); changed = true; }
      cat.prompts.forEach(p => {
        if (!p.id) { p.id = uid(); changed = true; }
      });
    });
    return changed;
  }

  // ============ 加载默认数据 ============
  async function fetchDefaults() {
    const url = chrome.runtime.getURL('prompts.json');
    const res = await fetch(url);
    const data = await res.json();
    ensureIds(data);
    return data;
  }

  // ============ 加载提示词数据 ============
  async function loadPrompts() {
    return new Promise((resolve) => {
      chrome.storage.local.get([STORAGE_KEY], async (result) => {
        if (result[STORAGE_KEY] && result[STORAGE_KEY].length > 0) {
          allPrompts = result[STORAGE_KEY];
          const changed = ensureIds(allPrompts);
          if (changed) await chrome.storage.local.set({ [STORAGE_KEY]: allPrompts });
        } else {
          allPrompts = await fetchDefaults();
          chrome.storage.local.set({ [STORAGE_KEY]: allPrompts });
        }
        resolve();
      });
    });
  }

  // ============ DOM 工具 ============
  function createEl(tag, attrs = {}, ...children) {
    const el = document.createElement(tag);
    Object.entries(attrs).forEach(([k, v]) => {
      if (k === 'className') el.className = v;
      else if (k === 'innerHTML') el.innerHTML = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2).toLowerCase(), v);
      else el.setAttribute(k, v);
    });
    children.forEach(c => {
      if (typeof c === 'string') el.appendChild(document.createTextNode(c));
      else if (c) el.appendChild(c);
    });
    return el;
  }

  // ============ Toast ============
  function showToast(msg) {
    let toast = document.getElementById(TOAST_ID);
    if (!toast) {
      toast = createEl('div', { id: TOAST_ID, className: 'ph-toast' });
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toast._timeout);
    toast._timeout = setTimeout(() => toast.classList.remove('show'), 2000);
  }

  // ============ 查找 DeepSeek 输入框 ============
  function findInputElement() {
    const selectors = [
      'textarea[placeholder*="发消息"]',
      'textarea[placeholder*="发送消息"]',
      'textarea[placeholder*="message"]',
      'textarea[placeholder*="输入"]',
      '#chat-input',
      '.chat-input textarea',
      '[role="textbox"]',
      '.ds-input textarea',
      'textarea'
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  // ============ 插入文本到输入框 ============
  function insertToInput(text) {
    const input = findInputElement();
    if (!input) {
      showToast('未找到输入框，请确保在 DeepSeek 聊天页面');
      return false;
    }

    input.focus();
    input.value = text;
    input.dispatchEvent(new Event('input', { bubbles: true }));

    // 选中第一个占位符
    const match = text.match(/\{\{(.+?)\}\}/);
    if (match) {
      input.setSelectionRange(match.index, match.index + match[0].length);
    } else {
      input.setSelectionRange(text.length, text.length);
    }

    input.scrollIntoView({ behavior: 'smooth', block: 'center' });
    showToast('已输入，可按 Tab 切换占位符');
    return true;
  }

  // ============ Tab 键切换占位符 ============
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Tab') return;
    const input = findInputElement();
    if (!input || document.activeElement !== input) return;
    const text = input.value;
    const placeholderRegex = /\{\{(.+?)\}\}/g;
    const matches = [...text.matchAll(placeholderRegex)];
    if (matches.length === 0) return;

    const pos = input.selectionStart;
    let nextMatch = matches.find(m => m.index > pos);
    if (!nextMatch) nextMatch = matches[0];

    e.preventDefault();
    input.setSelectionRange(nextMatch.index, nextMatch.index + nextMatch[0].length);
    input.focus();
  });

  // ============ 构建面板 ============
  function buildPanel() {
    const existingPanel = document.getElementById(PANEL_ID);
    if (existingPanel) existingPanel.remove();

    const searchInput = createEl('input', {
      className: 'ph-search-input',
      type: 'text',
      placeholder: '搜索提示词...'
    });

    const searchIcon = createEl('span', { className: 'ph-search-icon' }, '🔍');
    const searchWrap = createEl('div', { className: 'ph-search-wrap' }, searchIcon, searchInput);

    const promptList = createEl('div', { className: 'ph-prompt-list' });

    function renderPrompts(filter = '') {
      promptList.innerHTML = '';
      const keyword = filter.toLowerCase().trim();

      allPrompts.forEach(cat => {
        const filtered = keyword
          ? cat.prompts.filter(p =>
              p.title.toLowerCase().includes(keyword) ||
              p.text.toLowerCase().includes(keyword) ||
              cat.category.toLowerCase().includes(keyword)
            )
          : cat.prompts;

        if (filtered.length === 0) return;

        const catTitle = createEl('div', { className: 'ph-category-title' },
          cat.icon + ' ' + cat.category
        );

        const cards = filtered.map(p => {
          const preview = p.text.replace(/\n/g, ' ').substring(0, 60) + '...';
          const card = createEl('div', { className: 'ph-prompt-card' },
            createEl('div', { className: 'ph-prompt-title' }, p.title),
            createEl('div', { className: 'ph-prompt-preview' }, preview)
          );
          card.addEventListener('click', () => {
            if (insertToInput(p.text)) {
              card.classList.add('ph-prompt-inserted');
              setTimeout(() => card.classList.remove('ph-prompt-inserted'), 500);
            }
          });
          return card;
        });

        const categoryDiv = createEl('div', { className: 'ph-category' }, catTitle, ...cards);
        promptList.appendChild(categoryDiv);
      });
    }

    // 搜索防抖
    let searchTimer;
    searchInput.addEventListener('input', () => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => renderPrompts(searchInput.value), 200);
    });
    renderPrompts();

    // 面板头部
    const header = createEl('div', { className: 'ph-panel-header' },
      createEl('h2', {}, '提示词库'),
      createEl('button', { className: 'ph-btn-close', onClick: closePanel }, '✕')
    );

    // 组装面板
    const panel = createEl('div', { id: PANEL_ID, className: 'ph-panel' },
      header,
      searchWrap,
      promptList
    );

    document.body.appendChild(panel);
  }

  // ============ 触发按钮 ============
  function buildTrigger() {
    const existing = document.getElementById(TRIGGER_ID);
    if (existing) existing.remove();

    const btn = createEl('button', {
      id: TRIGGER_ID,
      className: 'ph-trigger-btn',
      title: '提示词助手',
      onClick: togglePanel
    }, '⚡');

    document.body.appendChild(btn);
  }

  // ============ 打开/关闭面板 ============
  function openPanel() {
    const panel = document.getElementById(PANEL_ID);
    const trigger = document.getElementById(TRIGGER_ID);
    if (panel) panel.classList.add('open');
    if (trigger) trigger.classList.add('active');
    isPanelOpen = true;
  }

  function closePanel() {
    const panel = document.getElementById(PANEL_ID);
    const trigger = document.getElementById(TRIGGER_ID);
    if (panel) panel.classList.remove('open');
    if (trigger) trigger.classList.remove('active');
    isPanelOpen = false;
  }

  function togglePanel() {
    isPanelOpen ? closePanel() : openPanel();
  }

  // ============ 监听来自 popup 的消息 ============
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'reloadPrompts') {
      loadPrompts().then(() => {
        buildPanel();
        sendResponse({ ok: true });
      });
      return true;
    }
    if (msg.action === 'insertPrompt') {
      insertToInput(msg.text);
      sendResponse({ ok: true });
    }
  });

  // ============ 快捷键 Ctrl+Shift+P 开关面板 ============
  document.addEventListener('keydown', function (e) {
    if (e.ctrlKey && e.shiftKey && e.key === 'P') {
      e.preventDefault();
      togglePanel();
    }
  });

  // ============ 启动 ============
  async function init() {
    await loadPrompts();
    buildPanel();
    buildTrigger();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
